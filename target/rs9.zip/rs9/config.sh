#
# Copyright (C) 2024 BlackMesa123
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#

# Device configuration file for Galaxy S21FE (Exynos) (r9s)
TARGET_NAME="Galaxy S21 FE (Exynos)"
TARGET_CODENAME="r9s"
TARGET_ASSERT_MODEL=("SM-G990E")
TARGET_PLATFORM="exynos2100"
TARGET_FIRMWARE="SM-G990E/THL/356350644558677"
TARGET_EXTRA_FIRMWARES=("")
TARGET_API_LEVEL=33
TARGET_PRODUCT_FIRST_API_LEVEL=30
TARGET_VNDK_VERSION=30
TARGET_SINGLE_SYSTEM_IMAGE="essi"
TARGET_OS_FILE_SYSTEM="ext4"
TARGET_SUPER_PARTITION_SIZE=11429478400
TARGET_SUPER_GROUP_NAME="group_basic"
TARGET_SUPER_GROUP_SIZE=11425284096
TARGET_HAS_SYSTEM_EXT=false
TARGET_INSTALL_METHOD=zip
TARGET_BOOT_DEVICE_PATH="/dev/block/by-name"

# SEC Product Feature
TARGET_AUTO_BRIGHTNESS_TYPE="5"
TARGET_DVFS_CONFIG_NAME="dvfs_policy_default"
TARGET_NFC_CHIP_VENDOR="SLSI"
TARGET_FP_SENSOR_CONFIG="google_touch_display_optical,settings=3"
TARGET_HAS_MASS_CAMERA_APP=false
TARGET_HAS_QHD_DISPLAY=false
TARGET_HFR_MODE="1"
TARGET_HFR_SUPPORTED_REFRESH_RATE="60,48,96,120"
TARGET_HFR_DEFAULT_REFRESH_RATE="120"
TARGET_DISPLAY_CUTOUT_TYPE="center"
TARGET_IS_ESIM_SUPPORTED=false
TARGET_MDNIE_SUPPORTED_MODES="61457"
TARGET_SSRM_CONFIG_NAME="siop_r9s_exynos2100"
TARGET_SUPPORT_CUTOUT_PROTECTION=false
TARGET_SUPPORT_WIFI_7=false
TARGET_SUPPORT_HOTSPOT_DUALAP=false
TARGET_SUPPORT_HOTSPOT_WPA3=false
TARGET_SUPPORT_HOTSPOT_6GHZ=false
TARGET_SUPPORT_HOTSPOT_WIFI_6=false
TARGET_SUPPORT_HOTSPOT_ENHANCED_OPEN=false
